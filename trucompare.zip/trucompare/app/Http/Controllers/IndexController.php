<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\models\userlogin;
use Illuminate\Support\Facades\Hash;
use App\models\invest;
use App\models\policy;
use Illuminate\Support\Facades\Input;

class IndexController extends Controller
{
    // LANDING PAGE CONTROLLER//
    function index()
    {
        $data = array(
            'list' => DB::table('detail')->get()
        );
        return view('curd/index', $data);
    }
    function add(Request $request)
    {

        $request->validate([

            'name' => 'required',
            'birth' => 'required',
            'gender' => 'required',
            'smoking' => 'required',
            'income' => 'required',
            'phone' => 'required',
            'email' => 'required|email|unique:detail',
            'city' => 'required'
        ]);
        $query = DB::table('detail')->insert([
            'name' => $request->input('name'),
            'birth' => $request->input('birth'),
            'gender' => $request->input('gender'),
            'smoking' => $request->input('smoking'),
            'income' => $request->input('income'),
            'phone' => $request->input('phone'),
            'email' => $request->input('email'),
            'city' => $request->input('city')
        ]);
        return redirect('compare');
        if ($query) {
            return back()->with('success', 'Date have been saved successfuly');
        } else {
            return back()->with('fail', 'something went wrong');
        }
    }
    // COMPARE CONTROLLER //
    function compare()
    {
        $data = array(
            'list' => DB::table('policies')->get()
        );
        return view('curd/compare', $data);
    }
    public function searchByprice(Request $req)
    {
        $list=policy::where('price','>=',$req->min)->where('price','<=',$req->max)->get();
        return view('curd/compare',compact('list'));
    }
   
    // MARKETLINKED PAGE CONTROLLER// 

    function marketlinked()
    {
        $data = array(
            'list' => DB::table('marketlinked')->get()
        );
        return view('curd/marketlinked', $data);
    }

    // Login //
    function login()
    {
        return view('curd/login');
    }
    public function loginuser(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8|max:12'
        ]);
        $user = userlogin::where('email', '=', $request->email)->first();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $request->session()->put('loginId', $user->id);
                return redirect('index');
            } else {
                return back()->with('fail', 'Password not matches.');
            }
        } else {
            return back()->with('fail', 'This email is not registered.');
        }
    }
    public function registration()
    {
        $data = array(
            'list' => DB::table('userlogins')->get()
        );
        return view("curd/registration");
    }
    public function registeruser(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'mobileNo' => 'required',
            'age' => 'required|numeric',
            'email' => 'required|email|unique:userlogins',
            'password' => 'required|min:8|max:12'
        ]);
        $user = new userlogin();
        $user->name = $request->name;
        $user->mobileNo = $request->mobileNo;
        $user->age = $request->age;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $res = $user->save();
        if ($res) {
            return back()->with('success', 'you have registered seccessfuly');
        } else {
            return back()->with('fail', 'something wrong');
        }
    }
    function invest($id)
    {
        $row = DB::table('policies')
            ->where('id', $id)
            ->first();
        $data = [
            'Info' => $row 
        ];
        return view('curd/invest', $data);
    }
    function abc()
    {
   //$result=DB::table('policy')
        //->join('userprofile','policy.id','=','userprofile.detailid')
        // ->select('policy.name','userprofile.username')
        // ->get();
        // echo"<pre>";
        //  print_r($result);
        //  echo "</pre>";
        //$data = array(
        //  'list'=>DB::table('policy')->get()
        //  return DB:: select('select name, price*10 as total  from policies');
        $helps= DB::table('policies')->select('name', 'youGet', 'youGive','price')->get();
        return view('curd/abc')->with('helps', $helps);
}
  public function searchBydate(Request $req)
 {
    $req->session()->put('policies', $req->input('price'));  
    echo $req->session()->get('policies');   
      // $helps=policy::where('price','>=',$req->min)->where('price','<=',$req->max)->get();
      //return view('curd/abc')->with(['helps'=> Policy::all()]);
     
    }



}
