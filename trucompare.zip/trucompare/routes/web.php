<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\RazorpayPaymentController;
use Illuminate\Support\Facades\Input;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Landing page //
Route::get('/index',[IndexController::class,'index']);
Route::post('/add',[IndexController::class,'add']);
Route::post('/compare',[IndexController::class,'compare'])->name('compare');

Route::get('/compare',[IndexController::class,'compare']);
//Route::post('/save',[IndexController::class,'save'])->name('save');
Route::post('/compare',[IndexController::class,'compare'])->name('compare');
Route::post('/compareuser',[IndexController::class,'compareuser'])->name('compareuser');
Route::post('/compare',[IndexController::class,'searchByprice'])->name('compare');

Route::get('/marketlinked',[IndexController::class,'marketlinked']);
Route::post('/marketlinked',[IndexController::class,'marketlinked'])->name('marketlinked');
/*user login*/
Route::get('/login',[IndexController::class,'login']);
//Route::post('/login',[IndexController::class,'login'])->name('login');

Route::post('/login-user', [IndexController::class, 'loginuser'])->name('login-user');

/**User registraion page */
Route::get('/registration', [IndexController::class, 'registration']);
Route::post('/register-user', [IndexController::class, 'registeruser'])->name('register-user');

Route::get('/invest', [IndexController::class, 'invest']);
Route::get('/invest', [IndexController::class, 'invest'])->name('invest');
Route::get('invest/{id}', [IndexController::class, 'invest']);

Route::get('/abc',[IndexController::class,'abc']);
Route::post('/abc',[IndexController::class,'abc'])->name('abc');
Route::post('/abc',[IndexController::class,'searchBydate'])->name('abc');

Route::get('payment', [RazorpayPaymentController::class, 'index']);
Route::post('payment', [RazorpayPaymentController::class, 'store'])->name('razorpay.payment.store');
