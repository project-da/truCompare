<!DOCTYPE html>
<html>

<head>
    <title>Investment</title>

    <!-- Import bootstrap cdn -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <!-- Import jquery cdn -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <!-- Import popper.js cdn -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <!-- Import javascript cdn -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- CSS stylesheet -->
    <style>
        html,
        body {
            height: 100%;
        }

        #green {

            background: #e7e5e5;
            text-align: center;
            color: black;
            padding: 15px;
        }

        nav.navbar.navbar-expand-lg.navbar-light.bg-primary {
            background-color: #e7e5e5 !important;
        }

        .table {
            width: 79%;
            height: 35vh;
            margin-left: 4%;
        }

        input.rupee {
            border: hidden;
        }

        span.inserted {
            font-size: 78%;
            margin-left: -40%;
        }

        select#pays {
            border: hidden;
            width: 91%;
        }

        label.pay {
            margin-left: -45%;
            font-size: 85%;
        }

        select#plan {
            border: hidden;
            width: 67%;
        }

        label.navbar-brand {
            font-size: 100%;
            padding: 1%;
        }

        input[type="text"] {
            border: none;
            width: 66%;
        }

        select#past {
            border: hidden;
            width: 16%;
        }

        label.navbar {
            margin-left: 10%;
        }

        i.fa.fa-inr {
            text-align: justify;
        }

        .container {
            background-color: whitesmoke;
            width: 374%;
            height: 148%;
            margin-left: -276%;
            margin-top: -90%;
        }

        .Advantage {
            margin-left: 32%;
        }

        img.get {
            width: 13%;
            text-align: justify;

        }

        label.get {
            font-size: 96%;
            text-align: justify;

        }

        .irr_block {
            font-size: 84%;
            text-align: justify;
        }

        .compare {
            font-size: 92%;
            text-align: justify;
        }

        .\> {
            margin-left: 67%;
            margin-top: -18%;
            border: hidden;
        }

        span.name.mt-2 {
            font-size: 90%;
            text-align: justify;
        }

       

        h6.matlab {
            margin-left: 20%;
            font-size: 92%;
        }

        strong.sky {
            font-size: 118%;
            color: #0a9edb;
        }

        strong.red {
            font-size: 119%;
            color: #ef1e1e;
            margin-left: 15%;
        }

        img.bulb {
            width: 15%;
        }

        button.btn.btn-sm.btn-danger {
            margin-left: 15%;
        }

        button.modalfade {
            border: hidden;
        }

        button.plantype {
            border: hidden;
            text-align: -webkit-match-parent;
        }

        .modal-dialog {
            width: 19%;
            margin-left: 21%;
            margin-top: 5%;
        }

        .buy_link {
            display: inline-block;
            text-transform: uppercase;
            font-weight: 800;
            font-size: 16px;
            line-height: 2px;
            font-family: 'Open Sans', sans-serif;
            color: #272323;
            margin-right: 100px;
            margin-top: 5px;
            position: relative;
            padding: 20px 20px 20px 20px;
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
            border: black;
        }

        ul.a {
            list-style-type: circle;
        }

        input.view {
            border: none;
            color: blue;
        }



        .guaranteed-vs-fd_wrp[_ngcontent-ohd-c74] {
    padding: 20px;
}
.guaranteed-vs-fd_compare[_ngcontent-ohd-c74] {
    display: flex;
    align-items: center;
    justify-content: center;
}
.guaranteed-vs-fd_compare[_ngcontent-ohd-c74] h1[_ngcontent-ohd-c74] {
    font-size: 16px;
    font-weight: 600;
    margin: 0 0 20px;
    position: relative;
}
.guaranteed-vs-fd_sub_heading[_ngcontent-ohd-c74] {
    display: flex;
    flex-direction: row;
    font-weight: 600;
    position: relative;
}
.guaranteed-vs-fd_sub_heading[_ngcontent-ohd-c74] span[_ngcontent-ohd-c74] {
    position: absolute;
    margin: 0 auto;
    left: 0;
    right: 0;
    display: flex;
    text-align: center;
    width: 27px;
    height: 27px;
    background: #fff;
    border-radius: 50px;
    top: 16px;
    font-size: 10px;
    justify-content: center;
    align-items: center;
}
.guaranteed_fixed_deposits[_ngcontent-ohd-c74], .guaranteed_milestone_plan[_ngcontent-ohd-c74] {
    float: left;
    width: 50%;
    text-align: center;
    font-size: 14px;
    padding: 7px 0;
}
.guaranteed_milestone_plan[_ngcontent-ohd-c74] {
    display: block;
    background: #e0eee1;
}
.guaranteed_fixed_deposits[_ngcontent-ohd-c74], .guaranteed_milestone_plan[_ngcontent-ohd-c74] {
    float: left;
    width: 50%;
    text-align: center;
    font-size: 14px;
    padding: 7px 0;
}
.guaranteed_fixed_deposits[_ngcontent-ohd-c74] {
    background: rgba(204,111,98,.34901960784313724) 0 0 no-repeat padding-box;
    display: flex;
    justify-content: center;
    align-items: center;
}
.modal-content {
    width: 259%;
    margin-left: -16%;
}
.guaranteed_investment[_ngcontent-ohd-c74] {
    margin-top: 20px;
}
.guaranteed_investment[_ngcontent-ohd-c74] p[_ngcontent-ohd-c74] {
    font-size: 14px;
    text-align: center;
    color: #757575;
    margin: 0;
    padding: 0;
}
.guaranteed_investment[_ngcontent-ohd-c74] h2[_ngcontent-ohd-c74] {
    text-align: center;
    color: #0652dd;
    margin: 0;
    padding: 0;
    font-size: 18px;
}
.guaranteed_investment_head[_ngcontent-ohd-c74] {
    background: #f2f6fe;
    text-align: center;
    padding: 4px 0;
    font-size: 14px;
    margin-top: 20px;
    color: #757575;
    font-weight: 500;
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] {
    display: flex;
    margin-top: 20px;
    align-items: center;
}
.guaranteed_investment_tax_free[_ngcontent-ohd-c74] {
    width: 50%;
    text-align: center;
    justify-content: center;
    border-right: 1px solid hsla(0,0%,43.9%,.25098039215686274);
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] b[_ngcontent-ohd-c74] {
    display: block;
    font-size: 16px;
    font-weight: 500;
}
.guaranteed_investment_tax_free[_ngcontent-ohd-c74] span[_ngcontent-ohd-c74] {
    width: 61px;
    font-size: 12px;
    color: #fff;
    background: #65ac68;
    margin: 0 auto;
    display: inline-block;
    border-radius: 2px;
}
.guaranteed_investment_taxable[_ngcontent-ohd-c74] {
    width: 50%;
    text-align: center;
    justify-content: center;
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] b[_ngcontent-ohd-c74] {
    display: block;
    font-size: 16px;
    font-weight: 500;
}
.guaranteed_investment_taxable[_ngcontent-ohd-c74] span[_ngcontent-ohd-c74] {
    width: 61px;
    font-size: 12px;
    color: #fff;
    background: #cc6f62;
    margin: 0 auto;
    display: inline-block;
    border-radius: 2px;
}
.guaranteed_investment_head[_ngcontent-ohd-c74] {
    background: #f2f6fe;
    text-align: center;
    padding: 4px 0;
    font-size: 14px;
    margin-top: 20px;
    color: #757575;
    font-weight: 500;
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] {
    display: flex;
    margin-top: 20px;
    align-items: center;
}
.guaranteed_investment_tax_free[_ngcontent-ohd-c74] {
    width: 50%;
    text-align: center;
    justify-content: center;
    border-right: 1px solid hsla(0,0%,43.9%,.25098039215686274);
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] b[_ngcontent-ohd-c74] {
    display: block;
    font-size: 16px;
    font-weight: 500;
}
.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] {
    width: 50%;
    text-align: center;
    justify-content: center;
}
.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] ul[_ngcontent-ohd-c74] {
    margin: 0 auto;
    list-style: none;
    width: 270px;
    float: left;
    display: block;
}
.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] ul[_ngcontent-ohd-c74] li[_ngcontent-ohd-c74] {
    margin: 0;
    padding: 0;
    list-style: none;
    width: auto;
    float: left;
    text-align: center;
    width: 32%;
}
.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] ul.tax_slab[_ngcontent-ohd-c74] {
    border: 0.6000000238418579px dashed #5c93f7;
    padding: 8px;
    border-radius: 4px;
    float: left;
    position: relative;
    margin-left: 30px;
    margin-top: 10px;
}

.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] ul[_ngcontent-ohd-c74] {
    margin: 0 auto;
    list-style: none;
    width: 270px;
    float: left;
    display: block;
}
.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] ul.tax_slab[_ngcontent-ohd-c74] span[_ngcontent-ohd-c74] {
    position: absolute;
    bottom: -8px;
    left: 0;
    right: 0;
    margin: 0 auto;
    background: #fff;
    width: 70px;
    padding: 0;
    font-size: 12px;
    color: #5c93f7;
}
.guaranteed_investment_returns_after_tax[_ngcontent-ohd-c74] ul[_ngcontent-ohd-c74] li[_ngcontent-ohd-c74] {
    margin: 0;
    padding: 0;
    list-style: none;
    width: auto;
    float: left;
    text-align: center;
    width: 32%;
}
.guaranteed_investment_head[_ngcontent-ohd-c74] {
    background: #f2f6fe;
    text-align: center;
    padding: 4px 0;
    font-size: 14px;
    margin-top: 20px;
    color: #757575;
    font-weight: 500;
}   
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] {
    display: flex;
    margin-top: 20px;
    align-items: center;
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] b[_ngcontent-ohd-c74] {
    display: block;
    font-size: 16px;
    font-weight: 500;
}
.guaranteed_investment_tax_free[_ngcontent-ohd-c74] {
    width: 50%;
    text-align: center;
    justify-content: center;
    border-right: 1px solid hsla(0,0%,43.9%,.25098039215686274);
}
.guaranteed_investment_taxable[_ngcontent-ohd-c74] {
    width: 50%;
    text-align: center;
    justify-content: center;
}
.guaranteed_investment_tax_free_wrp[_ngcontent-ohd-c74] b[_ngcontent-ohd-c74] {
    display: block;
    font-size: 16px;
    font-weight: 500;
}
    </style>
</head>

<body>

    <!-- h-100 takes the full height of the body-->
    <div class="container-fluid h-100">

        <!-- h-100 takes the full height 
                 of the container-->
        <div class="row h-100">
            <div class="col-2" id="green">
                <h4> LOGO</h4><br>

                <span class="name mt-3"> </span>
                <hr>

                <span class="name mt-2"> <strong> Invested Amount per month </strong> </span><br><br>
                <!-- Navigation links in sidebar-->

                <form action="/compare" method="post">
                    {{csrf_field()}}
                    <input type="hidden" name="min" value="500">&nbsp;
                    <input type="text" name="max">&nbsp;
                    <input type="submit" class="view" value="edit">
                </form>


                <hr>
                <span class="inserted">Change to <a href="#" class="inserted">yearly.</a>
                    <!---->
                </span> <br />
                <br />
                <label class="pay">You pay for:</label><br>
                <select name="pay" id="pays">
                    <option value="10 Years">10 Years</option>
                    <option value="7 Years">7 Years</option>
                    <option value="5 Years">5 Years</option>
                    <option value="One Time">One Time</option>
                </select>
                <hr>
                <div class="irr_block">
                    <span>Show Absolute Return</span>
                    <label class="toggle"><input _ngcontent-hqh-c9="" class="toggle-checkbox ng-untouched ng-valid ng-dirty" type="checkbox">
                        <div class="toggle-switch"></div>
                    </label>
                    <br> <span>Show TaxAdjusted Return</span>
                    <label class="toggle"><input _ngcontent-hqh-c9="" class="toggle-checkbox ng-untouched ng-pristine ng-valid" type="checkbox">
                        <div class="toggle-switch"></div>
                    </label>
                </div>
                <hr>
                <div class="compare"> Compare FD &amp;
                    <br>Guaranteed Plans
                </div>
                <div class=">"> <button type="button" data-toggle="modal" data-target="#exampleModal">
                        {{ __('>') }}
                    </button>
                </div>
            </div>
            <div class="col-10" style="padding: 0;">

                <!-- Top navbar -->
                <nav class="navbar navbar-expand-lg 
                                navbar-light bg-primary">

                    <button type="button" class="plantype" data-toggle="modal" data-target="#exampleModal1">
                        Plan type
                        <select name="plan" id="plan">
                            <option value="100% Guaranteed"> 100% Guaranteed</a></option>

                        </select></button>

                    <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="exampleModalLabel">Plan Type:</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <ul class="a">
                                    <li> <a href="{{ route('compare') }}" class="buy_link"> 100% Guaranteed</a></li>
                                    <li> <a href="{{ route('marketlinked') }}" class="buy_link"> Market Linked</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <label class="navbar">Get money as:</label>
                    <select name="past" id="past">
                        <option value="All plans">All plans</option>
                        <option value="Lumpsum">Lumpsum</option>
                        <option value="Income for 10 Yrs"> Income for 10 Yrs</option>
                        <option value="Income for 25 Yrs">Income for 25 Yrs</option>
                        <option value="Income for lifetime">Income for lifetime</option>
                    </select>
                </nav><br><br>
                <div>
                    <div class="row">
                        <div class="col-md-11">
                            <table class="table table-stripped table-bordered">

                                <tbody>
                                    @foreach($list as $item)
                                    <tr>
                                        <td width="2%">{{$item->id}}</td>
                                        <td width="15%">Buy Online & Get {{ $item->extra }} Extra <button type="submit" class="modalfade" name="submit" value="{{ $item->id}}">see more</button>
                                            <hr> <br><img src="{{ asset('assets/images/'. $item->image) }}" alt="images"> &emsp; {{ $item->name }}
                                        </td>
                                        <td width="5%"><br><br><br>YouGet<br> {{ $item->youGive }}</td>
                                        <td width="5%"><br><br><br>youGive <br>{{ $item->youGet }}</td>
                                        <td width="5%"><br><br><br>
                                            <a href="invest/{{ $item->id }}" class="btn btn-primary btn-xs"> Get Details</a>
                                            <!--   <button type="button" class="btn btn-sm btn-success" data-toggle="modal"  >
       
    {{ __('Details') }}
</button>-->
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="col-md-1">
                            <div class="container">
                                <hr>
                                <div class="Advantage"><strong>Advantage</strong></div>
                                <hr><br>
                                <img class="get" src="assets\images\get_extra.jpg">
                                <label class="get">Buy Online and Get Extra</label>
                                <h6 class="matlab">Matlab zyada fayda</h6><br>
                                <img class="get" src="assets\images\download.jpg">
                                <label class="get">100% Calls Recorded</label>
                                <h6 class="matlab">Honest Selling</h6><br>
                                <img class="get" src="assets\images\download2.jpg">
                                <label class="get">No Hidden Charges</label>
                                <h6 class="matlab">Full Transparency</h6><br>
                                <img class="get" src="assets\images\certified3.jpg">
                                <label class="get">Certified Advisors</label>
                                <h6 class="matlab">Keeping Customer First</h6><br>
                                <img class="get" src="assets\images\download4.jpg">
                                <label class="get">One click easy refund</label>
                                <h6 class="matlab">Hassle Free</h6><br>
                                <hr><br>
                                <img class="bulb" src="assets\images\bulb.svg">
                                <strong class="sky">Interest Rates </strong> have <strong class="red"> Consistently Fallen</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; in the last 5 years
                                <br><br>
                                <img class="graph" src="assets\images\Graphs.svg"><br><Br><br>
                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" style="width:70%"> Know More</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel">Return Comparison</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                    <div _ngcontent-ohd-c74="" class="inner_container">
                        <div _ngcontent-ohd-c74="" class="guaranteed-vs-fd_wrp">
                            
                            <!---->
                            <div _ngcontent-ohd-c74="" class="guaranteed-vs-fd_sub_heading"><span _ngcontent-ohd-c74="">vs</span>
                                <div _ngcontent-ohd-c74="" class="guaranteed_milestone_plan">Guaranteed Savings<br _ngcontent-ohd-c74="" class="ng-star-inserted">Plan
                                    <!---->
                                    <!---->
                                </div>
                                <div _ngcontent-ohd-c74="" class="guaranteed_fixed_deposits"> Fixed Deposits </div>
                            </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment">
                                <!---->
                                <p _ngcontent-ohd-c74="" class="ng-star-inserted">Your Investment Over 10 Years</p>
                                <!---->
                                <!---->
                                <h2 _ngcontent-ohd-c74="">₹ 1.2 Lacs</h2>
                            </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment_head"> Returns You Get </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment_tax_free_wrp">
                                <div _ngcontent-ohd-c74="" class="guaranteed_investment_tax_free">
                                    <!---->
                                    <!---->
                                    <!----><b _ngcontent-ohd-c74="" class="ng-star-inserted">5.85%</b>
                                    <!---->
                                    <!---->
                                    <!---->
                                    <!---->
                                    <!----><span _ngcontent-ohd-c74="">Tax Free</span>
                                </div>
                                <div _ngcontent-ohd-c74="" class="guaranteed_investment_taxable"><b _ngcontent-ohd-c74="">5.4%</b><span _ngcontent-ohd-c74="">Taxable</span></div>
                            </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment_head"> Returns After Tax </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment_tax_free_wrp">
                                <div _ngcontent-ohd-c74="" class="guaranteed_investment_tax_free">
                                    <!---->
                                    <!---->
                                    <!----><b _ngcontent-ohd-c74="" class="ng-star-inserted">5.85%</b>
                                    <!---->
                                    <!---->
                                    <!---->
                                    <!---->
                                    <!---->
                                </div>
                                <div _ngcontent-ohd-c74="" class="guaranteed_investment_returns_after_tax">
                                    <ul _ngcontent-ohd-c74="">
                                        <li _ngcontent-ohd-c74=""><b _ngcontent-ohd-c74="">4.96%</b></li>
                                        <li _ngcontent-ohd-c74=""><b _ngcontent-ohd-c74="">4.50%</b></li>
                                        <li _ngcontent-ohd-c74=""><b _ngcontent-ohd-c74="">4.03%</b></li>
                                    </ul>
                                    <ul _ngcontent-ohd-c74="" class="tax_slab"><span _ngcontent-ohd-c74="">Tax Slab</span>
                                        <li _ngcontent-ohd-c74="">
                                            <p _ngcontent-ohd-c74="">10%</p>
                                        </li>
                                        <li _ngcontent-ohd-c74="">
                                            <p _ngcontent-ohd-c74="">20%</p>
                                        </li>
                                        <li _ngcontent-ohd-c74="">
                                            <p _ngcontent-ohd-c74="">30%</p>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment_head"> In Case Of Death Your Family Gets </div>
                            <div _ngcontent-ohd-c74="" class="guaranteed_investment_tax_free_wrp">
                                <div _ngcontent-ohd-c74="" class="guaranteed_investment_tax_free"><b _ngcontent-ohd-c74="" class="ng-star-inserted">₹ 1.2 L</b>
                                    <!---->
                                    <!---->
                                </div>
                                <div _ngcontent-ohd-c74="" class="guaranteed_investment_taxable"><b _ngcontent-ohd-c74="">Zero</b></div>
                            </div>
                           
                    </div>
                </div>
               
            </div>
        </div>
    </div>
    </table>
    </div>
    <!--- //Modelbox---->


    </div>

</body>

</html>