<form action="add" method="POST">
<?php echo csrf_field(); ?> 
<input type="text" name="name" placeholder="name"><br><br>
<input type="text" name="email" placeholder="Email"><br><br>

<input type="text" name="address" placeholder="Address"><br><br>

<button type="submit"> Add member</buttton>







</form><?php /**PATH C:\xampp\htdocs\trucompare\resources\views/addmember.blade.php ENDPATH**/ ?>