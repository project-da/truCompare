<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="https://truca.in/public/assets/site/images/favicon.png" type="image/x-icon" />
    <title>CreateLeads</title>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/font-awesome.min.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/flaticon.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/animate.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/owl.carousel.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/odometer-theme-default.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/slick.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/slick-theme.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/slicknav.min.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/magnific-popup.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/jquery-isotope.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/metisMenu.min.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/jquery.fancybox.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://truca.in/public/assets/site/css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="https://truca.in/public/assets/site/css/dropzone-basic.min.css">
    <link rel="stylesheet" href="https://truca.in/public/assets/site/css/dropzone.min.css">
    <link href="https://truca.in/public/assets/site/css/sweetalert.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/newccs.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/style.css" rel="stylesheet" />
    <link href="https://truca.in/public/assets/site/css/responsive.css" rel="stylesheet" />
    <style>
        
        .modal {
            text-align: center;
        }

        @media  screen and (min-width: 768px) {
            .modal:before {
                display: inline-block;
                vertical-align: middle;
                content: " ";
                height: 100%;
            }
        }

        .modal-dialog {
            display: inline-block;
            text-align: left;
            vertical-align: middle;
            width: 100%;
        }

        .forgot {
            margin-bottom: 25px;
            font-size: 14px;
            float: right;
        }

        .forgot a {
            color: #134e8f !important;
        }

        .signup a {
            color: #134e8f !important;
        }
    </style>
    <style>
        .main_banner_form .error {
            margin-bottom: 0px !important;
        }
    </style>
</head>

<body>
    <!--<div class="" id="page-top" style="height: 80px;">
        <nav class="navbar navbar-expand-lg navbar-light bg-white navbar-nav" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="https://truca.in"><img src="https://truca.in/public/assets/site/images/logoCa.png"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="mega-menu-group"><a href="https://truca.in" class="nav-link"> Home </a></li>
                        <li class="mega-menu-group"><a href="https://truca.in/about_us" class="nav-link"> About Us </a></li>
                        <li class="mega-menu-group">
                            <a href="javascript:void(0)" class="nav-link"> Individual <i class="fa fa-angle-down" aria-hidden="true"></i> </a>
                            <div class="mega-menu-block">
                                <ul class="mega-menu-list-one">
                                    <li class="mega-menu-list-common  mega-menu-list-inner ">
                                        <a href="https://truca.in/product/individual/file-tax-returns">
                                            <span>File Tax Returns</span> <i class="fa fa-angle-right" aria-hidden="true"></i> </a>

                                        <ul class="mega-menu-list-two">
                                            <li><a href="https://truca.in/detail/salaried-individuals"> <span>Salaried Individuals</span> </a></li>
                                            <li><a href="https://truca.in/detail/capital-gains"> <span>Capital Gains</span> </a></li>
                                        </ul>
                                    </li>
                                    <li class="mega-menu-list-common  mega-menu-list-inner ">
                                        <a href="https://truca.in/product/individual/legal-services">
                                            <span>Legal Services</span> <i class="fa fa-angle-right" aria-hidden="true"></i> </a>

                                        <ul class="mega-menu-list-two">
                                            <li><a href="https://truca.in/detail/legal-drafting"> <span>Legal Drafting</span> </a></li>
                                            <li><a href="https://truca.in/detail/legal-documents-review"> <span>Legal Documents Review</span> </a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="mega-menu-group">
                            <a href="javascript:void(0)" class="nav-link"> Business <i class="fa fa-angle-down" aria-hidden="true"></i> </a>
                            <div class="mega-menu-block">
                                <ul class="mega-menu-list-one">
                                    <li class="mega-menu-list-common  mega-menu-list-inner ">
                                        <a href="https://truca.in/product/business/incorporate-your-business">
                                            <span>Incorporate your business</span> <i class="fa fa-angle-right" aria-hidden="true"></i> </a>

                                        <ul class="mega-menu-list-two">
                                            <li><a href="https://truca.in/detail/private-limited-company"> <span>Private Limited Company</span> </a></li>
                                        </ul>
                                    </li>
                                    <li class="mega-menu-list-common  mega-menu-list-inner ">
                                        <a href="https://truca.in/product/business/gst-services">
                                            <span>GST Services</span> <i class="fa fa-angle-right" aria-hidden="true"></i> </a>

                                        <ul class="mega-menu-list-two">
                                            <li><a href="https://truca.in/detail/gst-registeration"> <span>GST Registeration</span> </a></li>
                                        </ul>
                                    </li>
                                    <li class="mega-menu-list-common  mega-menu-list-inner ">
                                        <a href="https://truca.in/product/business/run-a-startup">
                                            <span>Run a Startup</span> <i class="fa fa-angle-right" aria-hidden="true"></i> </a>

                                        <ul class="mega-menu-list-two">
                                            <li><a href="https://truca.in/detail/payroll-services"> <span>Payroll Services</span> </a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="mega-menu-group"><a href="https://truca.in/contact_us" class="nav-link"> Contact Us </a></li>
                    </ul>
                    <a href="javascript:void(0)" class="loginbtn" data-toggle="modal" data-target="#loginmodal">Login</a>
                </div>
            </div>
        </nav>
    </div>-->
    

    <section class="main_banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <div class="owl-carousel2 owl-theme">
                        <div class="img-wrap">
                            <div class="main_banner_img">
                                <img src="https://truca.in/public/assets/site/images/img1.png" />
                            </div>
                        </div>
                        <div class="img-wrap">
                            <div class="main_banner_img">
                                <img src="https://truca.in/public/assets/site/images/b002.png" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5">
                    <div class="main_banner_form">
                        <form action="add" method="post">
                            <?php echo csrf_field(); ?>
                  
                                <!-- Your Trusted Partner<br />-->
                                <span>Get in Touch</span>
                            </label>
                            <input type="text" name="name" id="name" placeholder="Name" autocomplete="off" value="<?php echo e(old('name')); ?>">
                            <span style="color:red"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            <input type="text" name="email" id="email" placeholder="Email Address" autocomplete="off" value="<?php echo e(old('email')); ?>">
                            <span style="color:red"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            <input type="text" name="mobile" id="mobile" placeholder="Mobile Number" autocomplete="off" value="<?php echo e(old('mobile')); ?>">
                            <span style="color:red"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            <select name="city" id="city" >
                                <option value="">City</option>
                                <option value="293">chandiagrh</option>
                                <option value="1094">Mohali</option>
                                <option value="820">zirakpur</option>

                            </select>
                            <select name="category" id="category" value="<?php echo e(old('category')); ?>">
                                <option value="">Category</option>
                                <option value="1">Individual</option>
                                <option value="2">Business</option>
                            </select>
                            <select name="subcategory" id="subcategory" value="<?php echo e(old('subcategory')); ?>" >
                                <option value="">Sub Category</option>
                                <option value="1">sub category1</option>
                                <option value="2">sub category2</option>
                            </select>
                            <select name="product" id="product" value="<?php echo e(old('product')); ?>">
                                <option value="">Product</option>
                                <option value="1">product1</option>
                                <option value="2">product2</option>

                            </select>
                            <button type="submit" class="buy_link"  name="submit" id="btnSubmit">SAVE</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-1"></div>
            </div>
        </div>
    </section>


    <script src="https://truca.in/public/assets/site/js/jquery.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/bootstrap.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/jquery-plugin-collection.js"></script>
    <script src="https://truca.in/public/assets/site/js/jquery.slicknav.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/wow.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/sticky.js"></script>
    <script src="https://truca.in/public/assets/site/js/dropzone.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/jquery.validate.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/form_validations.js"></script>
    <script src="https://truca.in/public/assets/site/js/datatables.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/sweetalert.min.js"></script>
    <script src="https://truca.in/public/assets/site/js/script.js"></script>
    <script src="https://truca.in/public/assets/site/js/action.js"></script>
    <script>
        wow = new WOW({
            animateClass: "animated",
            offset: 100,
            callback: function(box) {
                console.log("WOW: animating <" + box.tagName.toLowerCase() + ">");
            },
        });
        wow.init();
    </script>
    <script type="text/javascript">
        $('.owl-carousel3').owlCarousel({
            loop: true,
            margin: 30,
            dots: true,
            nav: true,
            items: 1,
            autoplay: true,
            animateOut: "fadeOut",
            animateIn: "fadeIn",
        })
        $(".img-wrap2").each(function() {
            var img = $(this).find("img");
            var src = img.attr("src");
            $(this).css("background-image", "url( " + src + " )");
        });
    </script>
    <script type="text/javascript">
        $('.owl-carousel45').owlCarousel({
            loop: true,
            margin: 30,
            dots: false,
            nav: false,
            items: 1,
            autoplay: true,
            animateOut: "fadeOut",
            animateIn: "fadeIn",
        })
        //Background image
        $(".img-wrap").each(function() {
            var img = $(this).find("img");
            var src = img.attr("src");
            $(this).css("background-image", "url( " + src + " )");
        });
    </script>
    <script>
    </script>
    <script>
        function select_sub_category() {
            var main_category = $("#client_prd_main_category").val();

            $.ajax({
                url: "https://truca.in/select_lead_sub_category",
                type: "get",
                data: "main_category=" + main_category,
                success: function(data) {
                    $("#client_prd_sub_category").html(data);
                }
            });
        }

        function select_product() {
            var main_category = $("#client_prd_main_category").val();
            var sub_category = $("#client_prd_sub_category").val();

            $.ajax({
                url: "https://truca.in/select_lead_product",
                type: "get",
                data: "main_category=" + main_category + "&sub_category=" + sub_category,
                success: function(data) {
                    $("#client_prd_product").html(data);
                }
            });
        }

        function open_buynow(slug) {
            window.location.href = 'detail/' + slug;
        }
    </script>
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <!-- Import jquery cdn -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <!-- Import popper.js cdn -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script> 
    <!-- Import javascript cdn -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
</body>

</html><?php /**PATH C:\xampp\htdocs\trucompare\resources\views/curd/policy.blade.php ENDPATH**/ ?>