<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	<title>Document</title>
</head>
<style>
	.header-section {
		width: 100%;
		background: #fff;
		position: fixed;
		z-index: 999;
		border-bottom: 1px solid #C9C6C7;
	}

	div#logo {
		margin-left: 11%;
	}

	.container {
		width: 32%;
		background-color: #134e8f;
		padding: 27% 0% 2%;

		margin-left: 64%;
	}

	fieldset {
		background-color: whitesmoke;
		padding: 4%;
	}

	.carousel {
		position: relative;
		width: 700px;
		margin-top: 18%;
	}

	h1.top {
		margin-top: -81%;
		vertical-align: middle;
		text-align: center;
		color: white;
		font-weight: 800;
		font-size: 32px;
		font-family: Times New Roman;
	}

	.formLayout {
		background-color: #134e8f;

		padding: 12px;
		width: 100%;
	}

	.formLayout input {
		display: block;
		width: 100%;
		float: left;
		margin-bottom: 4px;
		height: 38px;
		padding-left: 5px;
	}

	.formLayout select {
		margin-bottom: 5px;
		border-radius: 5px;
		height: 37px;
	}

	.flex {
		display: flex;
		flex-wrap: wrap;
	}
</style>

<body>
	
		<div class="container">

			<div class="formLayout">
				<form action="add" method="post">
                <?php echo csrf_field(); ?>
					<h1 class="top">Top 5 Term Plans</h1>
					<div>
                  
						<div class="form-group">

							<input name="name" class="form-control" type="text"  placeholder="Name" id="name" value="<?php echo e(old('name')); ?>"><br>
                            <span style="color:red"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
						<div class="form-group">
							<label for="DOB">DOB:</label>
							<input type="date" name="birth" class="form-control" value="<?php echo e(old('birth')); ?>"/>
                            <span style="color:red"><?php $__errorArgs = ['birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
						<div class="form-group">
							<label for="Gender">Gender</label>
							<select class="form-control" name="gender" value="<?php echo e(old('gender')); ?>">
								<option>Male</option>
								<option>Female</option>
							</select>
                            
						</div>
						<div class="form-group">
							<label for="Smoking">Smoking</label>
							<select class="form-control" name="smoking" value="<?php echo e(old('smoking')); ?>"> 
								<option value="No">No</option>
								<option value="Yes">Yes</option>
							</select>
                           
						</div>
						<div class="form-group">
							<label for="Income">Income</label>
							<select class="form-control" name="income" value="<?php echo e(old('income')); ?>">
								<option value="Less than 3Lakhs">Less than 3Lakhs</option>
								<option value="3Lakhs - 5Lakhs">3Lakhs - 5Lakhs</option>
								<option value="5Lakhs - 7Lakhs" selected="selected">5Lakhs - 7Lakhs</option>
								<option value="7Lakhs - 10Lakhs">7Lakhs - 10Lakhs</option>
								<option value="More than 10lakhs">More than 10lakhs</option>
							</select>
                            
						</div>
						<div class="form-group">
							<input name="phone" type="text" class="form-control" maxlength="10" placeholder="Mobile Number" id="phno" value="<?php echo e(old('phone')); ?>">
                            <span style="color:red"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>

						<div class="form-group">

							<input name="email" type="text" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email" id="email" regex="^['_A-Za-z0-9-]+(\.['_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.(([A-Za-z]{2,3})|(aero|coop|info|museum|name))$"><br>
                            <span style="color:red"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
						<div class="form-group">
							<label for="City">City</label>
							<select class="form-control" name="city" id="city" value="<?php echo e(old('city')); ?>">
								<option value="">Select City</option>
								<option value="BANGALORE">BANGALORE</option>
								<option value="CHENNAI">CHENNAI</option>
								<option value="DELHI">DELHI</option>
								<option value="FARIDABAD">FARIDABAD</option>
								<option value="GHAZIABAD">GHAZIABAD</option>
								<option value="AURANGABAD">AURANGABAD</option>
								<option value="BAREILLY">BAREILLY</option>
								<option value="BEGUSARAI">BEGUSARAI</option>
								<option value="BHAGALPUR">BHAGALPUR</option>
								<option value="BHARUCH">BHARUCH</option>
								<option value="BHILAI">BHILAI</option>
								<option value="BHIWANI">BHIWANI</option>
								<option value="OTHER">OTHER</option>  
							</select>
                       
						</div>
						<div><input type="checkbox" class="form-control" id="chkagree" name="chkadgree" value="1" style="display: inline-block; width: auto; margin-right: 5px; height: 18px;" checked=""> <span style="color:#fff">I agree to <a href="http://www.trucompare.in/term_condition.php" target="_blank" style="color:#FD772F">terms and conditions</a> and <a href="http://www.trucompare.in/privacy.php" target="_blank" style="color:#FD772F">privacy policy </a> </span></div><br>
							<div class="form-group">
                            <button type="submit" class="btn btn-primary">SAVE</button>
                        </div>
					</div>
				</form>
				</div>
		</div>

				<br>

<table class="table table-hover">
   <thead>
	<th>Name</th>
	<th>DOB</th>
	<th>Gender</th>
	<th>Smoking </th>
	<th>Income</th>
	<th>Phone no</th>
	 <th>Email</th>
	 <th>City</th>
	 </thead> 
	 <tbody>
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($item->name); ?> </td>
<td><?php echo e($item->birth); ?> </td>
<td><?php echo e($item->gender); ?></td>
<td><?php echo e($item->smoking); ?></td>
<td><?php echo e($item->income); ?></td>
<td><?php echo e($item->phone); ?></td>
<td> <?php echo e($item->email); ?> </td>
<td><?php echo e($item->city); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
		
	<br><Br>


</body>

</html><?php /**PATH C:\xampp\htdocs\trucompare\resources\views/curd/landingpage.blade.php ENDPATH**/ ?>