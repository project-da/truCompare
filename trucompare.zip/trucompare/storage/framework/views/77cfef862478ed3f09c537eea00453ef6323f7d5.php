<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="/abc " method="post" >
<?php echo e(csrf_field()); ?>

<input type="hidden"  name="min" value="500">&nbsp;
<input type="text"  name="max">&nbsp;
<input type="submit" value="view">
  </form>
  <table border="1">
    <tr>
     
<th>name</th>
<th>youGet</th>
<th>youGive</th>
<th>price</th>
<th>Total</th>

    </tr>
    <?php $__currentLoopData = $helps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $help): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    
      <td><?php echo e($help->name); ?></td>
      <td><?php echo e($help->youGet); ?></td>
      <td><?php echo e($help->youGive); ?></td>
      <td><?php echo e($help->price); ?></td>

 

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\trucompare\resources\views/curd/abc.blade.php ENDPATH**/ ?>